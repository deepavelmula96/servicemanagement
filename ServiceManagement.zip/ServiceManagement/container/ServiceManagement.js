
import React, { Component } from 'react'
import { connect } from 'react-redux'
import ServiceManagementAction from '../components/ServiceManagementAction'

export class ServiceManagement extends Component {
  
    render() {
        return (
            <div>
          <h1>service management</h1>
          <ServiceManagementAction/>
            </div>
        )
    }
}

export default connect(null,null) (ServiceManagement)
