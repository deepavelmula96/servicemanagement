import React from 'react'
import { useDispatch } from 'react-redux'

const ServiceManagementListParent = () => {
    const dispatch=useDispatch()
    return (
        <div>
            Service Code: TNX0027
Service Category: Transactional Alert Messages
Service Priority: High priority Transaction Alerts
Status: Active
        </div>
    )
}

export default ServiceManagementListParent
