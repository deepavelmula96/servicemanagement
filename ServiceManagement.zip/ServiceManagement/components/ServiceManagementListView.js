import React from 'react'
import { useDispatch } from 'react-redux'

const ServiceManagementListView = () => {
    const dispatch=useDispatch()
    return (
        <div>
        </div>
    )
}

export default ServiceManagementListView
