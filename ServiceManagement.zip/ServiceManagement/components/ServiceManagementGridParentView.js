import React from 'react'
import { useDispatch } from 'react-redux'

const ServiceManagementGridParentView = () => {
    const dispatch=useDispatch()
    return (
        <div>
        </div>
    )
}

export default ServiceManagementGridParentView
