import React,{ useEffect,useState } from 'react'

import { useDispatch } from 'react-redux'

const ServiceManagementAction = () => {
    const dispatch=useDispatch()
    const [state, setstate] = useState({
        category:[],
        selectedCategory:'',
        priority:[],

    })
    useEffect(()=>{
        setstate({
            category:[
              { name:'CRT(Critical Alerts Messages)',priority:['Reserved','Fraud Alerts','System/ApplicationCritical Alerts']},
              {name:'TXN(Transactional Alert Messages)',priority:['For OTPs Only','High priority Transaction Alerts','Medium Priority Transaction Alerts','Low Priority Transaction Alerts','Quick Message','Batch Transactions']},
              {name:'CMP(Promotional/campaign messages)',priority:['High Priority Promotional Alerts','Medium Priority Promotional Alerts','Low Priority Promotional Alerts']}
            ]
        })
    },[])
    const selectedChange=(e)=>{
        setstate({selectedCategory:e.target.value})
        setstate({priority:state.category.find(x=>x.name===e.target.value).priority})
    }
    return (
        <div>
            <select value={state.selectedCategory} onChange={(e)=>selectedChange(e)}>
                {state?.category?.map(x=>{
                    return<option>{x?.name}</option>
                })}
            </select>
            <select>
                {state?.priority?.map(x=>{
                    return<option>{x}</option>
                })}
            </select>
        </div>
    )
}

export default ServiceManagementAction
