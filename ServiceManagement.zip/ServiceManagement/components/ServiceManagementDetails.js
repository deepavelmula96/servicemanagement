import React from 'react'
import { useDispatch } from 'react-redux'

const ServiceManagementDetails = () => {
    const dispatch=useDispatch()
    return (
        <div>
        </div>
    )
}

export default ServiceManagementDetails
